1:"$Sreact.fragment"
2:I[4777,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/133rq7uo7d2_0.js","/_next/static/chunks/10~36d.6aqr6d.js","/_next/static/chunks/0~w_1pp7p00y6.js"],"CanvasLanding"]
3:I[97367,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/0~w_1pp7p00y6.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"z-yHvf5lGnIedVMkzd1JK"}
5:null
