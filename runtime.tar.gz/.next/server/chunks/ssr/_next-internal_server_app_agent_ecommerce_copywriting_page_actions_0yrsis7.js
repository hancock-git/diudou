module.exports=[69734,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_agent_ecommerce_copywriting_page_actions_0yrsis7.js.map