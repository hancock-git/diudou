module.exports=[67170,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_agent_ecommerce_canvas_%5Bid%5D_page_actions_06h_00w.js.map