module.exports=[56606,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_agent_ecommerce_settings_page_actions_0bri_6..js.map