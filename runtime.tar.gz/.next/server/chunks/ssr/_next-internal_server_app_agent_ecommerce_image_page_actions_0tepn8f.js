module.exports=[96929,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_agent_ecommerce_image_page_actions_0tepn8f.js.map