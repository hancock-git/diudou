module.exports=[5900,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_agent_ecommerce_video_page_actions_08s-4-j.js.map