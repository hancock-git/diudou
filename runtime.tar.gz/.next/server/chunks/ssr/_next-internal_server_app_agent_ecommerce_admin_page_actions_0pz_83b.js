module.exports=[99397,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_agent_ecommerce_admin_page_actions_0pz_83b.js.map