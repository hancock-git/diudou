module.exports=[28695,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_agent_ecommerce_remix_page_actions_073hnnl.js.map