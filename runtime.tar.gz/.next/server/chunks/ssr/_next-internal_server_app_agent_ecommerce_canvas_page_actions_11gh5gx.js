module.exports=[30643,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_agent_ecommerce_canvas_page_actions_11gh5gx.js.map